# Update this before release
VERSION = "0.3.1"
